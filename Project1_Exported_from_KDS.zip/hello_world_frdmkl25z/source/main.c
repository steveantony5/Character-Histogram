/*
 * Copyright (c) 2013 - 2014, Freescale Semiconductor, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of Freescale Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

// Header files
#include "main.h"

uint32_t *ptr_start = NULL, *ptr_end = NULL;
char parameters[40];

volatile int32_t counter = 0;

#ifdef FRDM
void strparam()
{
	  int i = 0;
	  while ((parameters[i-1] != '\n') && (parameters[i-1] != '\r'))
	  {
		  parameters[i] = GETCHAR();
		  PUTCHAR(parameters[i]);
		  i++;
	  }

}
#endif

//creating a structure for lookup table
typedef struct lookup
{
	int (*func1)(char[]);
	char name[10];
}table;



int main (void)
{

    // Initialize standard SDK demo application pins
#ifdef FRDM
	hardware_init();
	sys_init();
#endif


	/*for the user input*/
	char input[10];

	/*for getting the parameters*/
	//char parameters[40];

	PRINT("\n\r********************* Welcome******************************\n\r");


	PRINT("To invoke the help function, type \"help\"\n\r");

#ifdef FRDM
	setvbuf(stdin, NULL, _IONBF, 0);
	setvbuf(stdout, NULL, _IONBF, 0);
#endif

	while(1)
	{

		PRINT("\n\rEnter your command\n\r>>");

		/*resetting the input variable*/
		memset(input,0,sizeof(input));
#ifdef FRDM
        SCANF("%s",input);
#else
		fgets(input,10,stdin);
		/*adding \0 to the last character such that it perfectly compares in the look up*/
		int8_t len = strlen(input);
		input[len-1] = '\0';
#endif
        PRINT("%s",input);



		memset(parameters,0,sizeof(parameters));
		if(!((strcmp(input,"exit") == 0) ||( strcmp(input,"help")==0)||(strcmp(input,"free")==0)))
		{
			PRINT("\n\rEnter parameters\n\r");
#ifdef LINUX
			fgets(parameters,40,stdin);
#else
			strparam();
#endif
		}

		//to exit from the program
		if(strcmp(input,"exit")==0)
			exit(0);

		//look up table
		table table_lookup[] =
		{
			{help,"help"},
			{free_memory,"free"},
			{allocate,"allocate"},
			{display,"display"},
			{invert,"invert"},
			{write_memory,"write"},
			{generate,"generate"},
			{verify,"verify"},
			{NULL," "}
		};

		uint32_t flag = 0;//used to set when user enters an invalid command
		for(int8_t i=0;(table_lookup[i].func1)!=NULL ; i++)
		{
			//comparing the user option in the lookup table
			if(strcmp((table_lookup[i].name),(input))==0)
			{
				//calling the function
				(table_lookup[i].func1)(parameters);
				flag = 1;//sets 1 if match is found in lookup table
				break;

			}
		}
		if(flag == 0)//enters if the user entered an invalid command
		      PRINT("\n\rYou have entered an invalid command\n\rPlease type \"help\" for help\n\r");

	}
	return 0;

}

#ifdef FRDM

void sys_init()
{
		SYSTICK_VAL = 0x0;    //clear current timer value
		SYSTICK_LOAD = 0xBB80;
		SYSTICK_CTRL = 0x7;
}

void SysTick_Handler(void)
{
	counter++;
	if(counter == 2147483645)
		counter = 0;
}
#endif
