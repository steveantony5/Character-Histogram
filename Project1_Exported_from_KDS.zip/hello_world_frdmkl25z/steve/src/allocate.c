/**************************************************************************
 *  File name : allocate.c
 * Author : Steve and Swarupa
 *
 * Description : This program helps in allocating memory for the user
 * **********************************************************************/


/*Header files*/
#include "allocate.h"

int allocate(char param[40])
{

		/*for storing the string of number variable*/
		char number_str[10];
		memset(number_str,0,sizeof(number_str));

		/* for getting the number of memory blocks to be allocated*/
		uint32_t number = 0;

		/*separating the input parameters*/
		sscanf(param,"%s",number_str);


		/*converting string to integer*/
		number = str_to_int(number_str);	

		if(number == 0)
			goto end;
		// allocating memory using malloc()
		ptr_start = (uint32_t *) malloc((number)*sizeof(uint32_t));

		// checking if the block of memory has been successfully allocated
		if(ptr_start!=NULL)
		{
			PRINT("\n\rAllocated %d number of 32bits successfully\n\r",number);

			/*Storing the end address of the allocated memory block*/
			ptr_end = ptr_start + (number);

#ifdef LINUX
			PRINT("\n\rThe block of memory allocated starts from %p \n\r",ptr_start);
#else
			PRINT("\n\rThe block of memory allocated starts from %x \n\r",ptr_start);
#endif
			PRINT("\n\r*********************************************************\n\r");
			return 1;
		}
		else
		end:    PRINT("\n\rMemory not allocated\n\r");
			return 0;
}
