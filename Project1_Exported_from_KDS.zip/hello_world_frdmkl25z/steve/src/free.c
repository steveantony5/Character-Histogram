/****************************************************************
  * Author : Steve and Swarupa
 * File name : free.c
 * Date created : 09/25/2018
 *
 * Description: This .c file is used for freeing the previously allocated memory block
 * *************************************************************/

#include "free.h"

int free_memory(char param[40])

{
	/*freeing the allocated memory using free()*/
	free(ptr_start);
#ifdef LINUX
	PRINT("\n\rThe previous alocated memory block starting from %p has been freed\n\r",ptr_start);
#else
	PRINT("\n\rThe previous alocated memory block starting from %x has been freed\n\r",ptr_start);
#endif

	PRINT("\n**********************************************************************************\n");
	return 1;
}

