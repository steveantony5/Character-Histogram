/***********************************************************************
 *Author : Steve and Swarupa
 *File name: display.c
 *Date created : 09/28/2018
 *
 *Description: This .c file is written to display the contents of the memory.
 **********************************************************************/

/*Header files*/
#include "display.h"
int display(char param[40])
{

	/*For checking if the user's address input is a valid address*/
	uint32_t *ptr= NULL;

#ifdef FRDM
	/*For storing the absolute address*/
	int32_t abs_address = 0;
	
	/*For getting the address input*/
	int32_t address = 0;

#else
	/*For storing the absolute address*/
		int64_t abs_address = 0;

		/*For getting the address input*/
		int64_t address = 0;
#endif
	/*For setting if it is a valid address*/
	int8_t flag =0;

	/*For getting the number of memory blocks to be displayed*/
	int32_t number = 0;

	/*Option for the type of address input*/
	char address_option[10];
	memset(address_option,0,sizeof(address_option));

	/*for storing the address and number of blocks to display as input strings*/
	char address_str[15];
	char number_str[10];
	memset(address_str,0,sizeof(address_str));
	memset(number_str,0,sizeof(number_str));

	/*Separating the input parameters*/
	/*When address is of abs type*/
	sscanf(param,"%s",address_option);
	if(strcmp(address_option,"abs")==0)
	{
			sscanf(param,"%s%lx%s",address_option,&address,number_str);
	        /*Converting string to integer*/
	        number = str_to_int(number_str);
        }
	/*Separating the input parameters when address is of block type*/
	else
	{
			sscanf(param,"%s%s%s",address_option,address_str,number_str);
	       /*converting string to integer*/
	       address = str_to_int(address_str);
	       number = str_to_int(number_str);
        }


	/*if the user enters an absolute hexa decimal address*/
	if(strcmp(address_option,"abs")==0)
	{
		abs_address = address;	
		/*checks if it is valid address*/
		for((ptr=ptr_start); (ptr!=ptr_end);ptr++)
        	{
			/* Ensures it is a valid address only if it the start address of any of the allocated block*/
                	if(ptr == (uint32_t *) abs_address)
                	{
	                	PRINT("\n\rValid address\n\r");
	                	/*Sets flag to 1 if it is a valid address*/
				flag =1;
	        	}
		}

		/*Flag remains 0 if it is not a valid address*/
		if(flag ==0)
		{
			if (ptr_start ==NULL)
			{
				/*Condition to check if memory has been allocated yet*/
				PRINT("\n\raddress not allocated, Please type allocate to proceed\n\r");
				/*Goes to the end of the function if it ia not a valid address*/
				ptr = NULL;
				goto end;
			} 
			else
			{
			        /*Condition to check if user entered invalid address*/
		       		PRINT("\n\r Not a valid address\n\r");
		       		/*goes to the end of the function if the address is not a valid address*/
		       		ptr = NULL;
				goto end;
			}

		}
	}

	/*if the user enter the block number as address input*/
	else if(strcmp(address_option,"block")==0)
	{
		/*checks if the block number is valid*/
		int32_t block_no_count;
		for((ptr = ptr_start), (block_no_count = 1);(ptr!=ptr_end);ptr++,block_no_count++)
		{
			/*assigns the address from the block number input*/
			if(block_no_count == address)
			{
				PRINT("\n\rValid memory block\n\r");

#ifdef FRDM
				abs_address = (int32_t)ptr;
#else
				abs_address = (int64_t)ptr;
#endif

				/*Flag is set if it is a valid block*/
				flag = 1;
			}
		}

		/*Enters if the address is not valid*/
		if(flag ==0)
		{
			 if (ptr_start ==NULL)
			 {
                //Condition to check if memory has been allocated yet
	            PRINT("\n\raddress not allocated, Please type allocate to proceed\n\r");
			    /*Goes to the end of the function if it ia not a valid address*/
			    ptr = NULL; 
			    goto end;
			 } 
			 else
	         {
               //Condition to check if user entered invalid address
               PRINT("\n\r Not a valid address\n\r");
			   /*Goes to the end of the function*/
			   ptr = NULL;
			   goto end;
			 }
		}

	}
      else
	{
		/*enters if the user enters an invalid address type*/
		PRINT("\n\rNot a valid input address type\n\r");
		ptr = NULL;
		goto end;
	}		
		
		
	ptr = NULL;	
	/*counts the number of blocks available from the start address given by user*/
	int32_t count = 0;
	for((ptr= (uint32_t *)abs_address); (ptr!=ptr_end);(ptr++))
	{
	       count++;
	}

	/*checks if the blocks requested by the user to be displayed is less than or equal to the 
	 * number of available blocks in the allocated region of memory*/
	if(number>count)
	{
	      PRINT("\n\rYour requested number of blocks to display is greater than the accessible memory blocks available\n\r");
							                
	      /*If the requested memory blocks to be displayed is greater than the number of available memory blocks,
	       * get the number of blocks to be displays again*/
	      ptr = NULL;
	      goto end;
	}
	/*Display the number of blocks requested*/
	ptr = (uint32_t *)abs_address;
	for(int32_t i =1; i<=number;i++,ptr++)
	{
#ifdef LINUX
		PRINT("\n\rThe content of %p memory is %x\n\r",(ptr),(*ptr));
#else
		PRINT("\n\rThe content of %x memory is %x\n\r",(ptr),(*ptr));
#endif
	}

	end:
	PRINT("\n\r******************************************\n\r");
	if(ptr!=NULL)
		return 1;
	else
		return 0;
}


