/************************************************************************************
 * File name: help.c
 * Author: Steve and Swarupa
 * *********************************************************************************/


// header files
#include "help.h"



int help(char param[40])
{
	
        PRINT("allocate   - >> allocate \n\r\
                            >>Parameter - (\"no_of_blocks\").\n\r\
               free       - >>free\n\r\
               display    - >>display \n\r\
                            >>parameters - (\"address_type\" \"no_of_block/absolute_address\" \"total_blocks_to_display\")\n\r\
               write	  - >>write \n\r\
                            >> parameters - (\"address_type\" \"no_of_block/abs_address\" \"data\")\n\r\
               invert      ->>invert\n\r\
                            >> Parameters - (\"address_type\" \"block_number/abs_address\" \"total_blocks_to_invert\")\n\r\
               generate   - >>generate\n\r\
        		            >> Parameters -  (\"address_type\" \"block_number/abs_address\" \"seed_value\" \"Length_of_pattern\")\n\r\
               verify     - >>verify\n\r\
        		            >> Parameters -  (\"address_type\" \"block_number/abs_address\" \"seed_value\" \"Length_of_pattern\")\n\r");
	return 1;	
}

				
