/***********************************************************
 * Author : Steve and Swarupa
 * Filename : invert.c
 * Date created : 09/28/2018
 *
 * Description : This .c file is used for inverting data in the memory block
 * ********************************************************/

/*Header Section*/
#include "invert.h"

int invert(char param[40])
{
#ifdef FRDM

	uint32_t cnt_start_value;
	uint32_t cnt_end_value;
    uint32_t execution_cycle;    //actual execution cycle
#endif
	/*For checking if the address is a valid address*/
	uint32_t *ptr = NULL;

	/*For setting if it is a valid address*/
	int8_t flag =0;
	
#ifdef FRDM
	/*For geting the address given by user*/
	int32_t address = 0;
	

	/*For storing the absolute address*/
	int32_t abs_address = 0;
#else
	/*For geting the address given by user*/
		int64_t address = 0;


		/*For storing the absolute address*/
		int64_t abs_address = 0;
#endif
	/*Option for the type of address input*/
	char address_option[10];
	memset(address_option,0,sizeof(address_option));

	/*For storing the number of blocks to invert*/
	uint32_t number = 0;

	/*For storing the number of blocks string*/
	char number_str[10];
	memset(number_str,0,sizeof(number_str));

	/*For string the address string*/
	char address_str[16];
	memset(address_str,0,sizeof(address_str));

	/*Separating the input parameters*/
	/*When address is of abs type*/
	sscanf(param,"%s",address_option);
	if(strcmp(address_option,"abs")==0)
	{
		sscanf(param,"%s%lx%s",address_option,&address,number_str);
		/*Converting string to integer*/
		number = str_to_int(number_str);

	}
	/*Separating the input parameters when address is of block type*/
	else
	{
		sscanf(param,"%s%s%s",address_option,address_str,number_str);
		/*converting string to integer*/
                address = str_to_int(address_str);
		number = str_to_int(number_str);

        }

	/*Enters if address is entered in hexadecimal format*/
	if(strcmp(address_option,"abs")==0)
	{
		abs_address = address;
	
		/*Checks if the address is a valid address*/

		for((ptr=ptr_start); (ptr!=ptr_end);ptr++)
		{
			/*Checks if the address is the start address of any allocated blocked*/
			if(ptr == (uint32_t *)abs_address)
			{
				PRINT("\n\rValid Address\n\r");
				/*Flag set to 1 if it is a valid address*/
				flag =1;
			}
		}	

		/*Flags remains 0 if it is not a valid address*/
		if(flag==0)
		{
			if (ptr_start == NULL)
			{
			        //Condition to check if memory has been allocated yet
                    PRINT("\n\raddress not allocated, Please type allocate to proceed\n\r");
                    /*Goes to the end of the function if it ia not a valid address*/
                    ptr = NULL;
                    goto end;
            }
            else
            {
                    //Condition to check if user entered invalid address
                	PRINT("\n\rNot a valid address\n\r");
                    /*Goes to the end of the function*/
                	ptr = NULL;
                    goto end;
            }
		}
	}

	/*Enters if address is entered as block number*/
	else if(strcmp(address_option,"block")==0)
	{
		/*Assign actual address from block number*/
		int32_t block_no_count;
		for((ptr = ptr_start), (block_no_count = 1);(ptr!=ptr_end);ptr++,block_no_count++)
		{
			if(block_no_count == address)
			{
				PRINT("\n\rValid memory block\n\r");
#ifdef FRDM
				abs_address = (int32_t)ptr;
#else
				abs_address = (int64_t)ptr;
#endif
				/*Sets if it is a valid block*/
				flag = 1;
			}
		}

		/*Enters if the block is not valid*/
		if(flag ==0)
		{
		        PRINT("\n\rNot a valid memory block, Please choose a command to proceed\n\r");
		        /*goes to the end of the function if the address is not a valid address*/
		        ptr = NULL;
		        goto end;
		}

	}
	else
	{
		/*enters if the user enters an invalid address type*/
		PRINT("\n\rNot a valid input address type\n\r");
		ptr = NULL;
		goto end;
	}		

	/*Counts the number of memory blocks available from the address given by the user*/
	int32_t count = 0;
	for((ptr=(uint32_t *)abs_address); (ptr!=ptr_end);(ptr++))
	{
	        count++;
	}

	/*Checks if the number of blocks to invert is greater than the number of available memory blocks*/
        if(number>count)
        {
                PRINT("\n\rYour requested number of blocks to display is greater than the accessible memory blocks available\n\r");
                ptr = NULL;
		goto end;
        }


	/*Holds the result after inverting*/
	uint32_t result = 0;
#ifdef LINUX
	/*Inputs the start time of invert operation*/
	clock_t begin = clock();
#else

	cnt_start_value = counter;

#endif
	/*Counts the number of memory blocks available from the start of the user entered memory address*/
	ptr= (uint32_t *)abs_address;
        for(int8_t count = 1; count<=number;count++,ptr++)
	{
#ifdef LINUX
		PRINT("\n\rThe content of %p memory is %x\n\r",ptr,(*ptr));
#else
		PRINT("\n\rThe content of %x memory is %x\n\r",ptr,(*ptr));
#endif
        	/*EXORed with 4294967295  for inverting the data*/
		result = (*ptr)^(FULL_RANGE_VALUE);
		PRINT("\n\rThe XOR resut is %x \n\r",result);

		*ptr = result;

	}

#ifdef LINUX

	/*Getting the end time of invert operation*/
	clock_t end = clock();

	/*Calculate the time taken between start and end*/
	double time_taken = (double) (end - begin)/CLOCKS_PER_SEC;

	PRINT("The time taken for the inversion operation is %lf seconds\n",time_taken);
#else
	cnt_end_value = counter;

	execution_cycle = cnt_end_value - cnt_start_value;
	PRINT("The time taken for the inversion operation is %d ms\n\r", execution_cycle);


#endif

end:
	PRINT("\n\r*********************************************************\n\r");
	if(ptr!=NULL)
		return 1;
	else
		return 0;

}


