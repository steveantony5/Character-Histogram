/*********************************************************
 * Author : Steve and Swarupa
 * Filename: verify.c
 * Date Created: 09/30/2018
 *
 * Description: This .c file verifies the pattern stored in memory is correct based on the seed value and length
 * *******************************************************/
/*Header Section*/
#include "verify.h"
int verify(char param[40])
{
#ifdef FRDM
	uint32_t cnt_start_value;
	uint32_t cnt_end_value;
    uint32_t execution_cycle;    //actual execution cycle
#endif
	/*For checking if the address is a valid address*/
	uint32_t *ptr = NULL;

	/*Holds the seed value for which the pattern has to be verified*/
	uint32_t ver_seed = 0;

#ifdef FRDM
	/*Holds the address where the pattern is stored and has to be verified*/
	int32_t address = 0;

	/*For storing the abs address*/
	int32_t abs_address = 0;
#else
	/*Holds the address where the pattern is stored and has to be verified*/
		int64_t address = 0;

		/*For storing the abs address*/
		int64_t abs_address = 0;
#endif

	/*For setting if it is a valid address*/
	int8_t flag =0;
	
	/*For string the length of pattern*/
	uint32_t ver_length = 0;
	
	/*Option for the type of address input*/
	char address_option[10];
	memset(address_option,0,sizeof(address_option));

	/*For storing the input trings*/
	char seed_str[10],length_str[10],address_str[20];
	memset(seed_str,0,sizeof(seed_str));
	memset(length_str,0,sizeof(length_str));
	memset(address_str,0,sizeof(address_str));

	/*Separating the inputs parameters when address is of abs type*/
	sscanf(param,"%s",address_option);

	if(strcmp(address_option,"abs")==0)
	{
			sscanf(param,"%s%lx%s%s",address_option,&address,seed_str,length_str);
	       /*converting from string to integers*/	
	       ver_seed = str_to_int(seed_str);
	       ver_length = str_to_int(length_str);
	}

        /*Separating the input parameters when address is of block type*/
        else
	{
        	sscanf(param,"%s%s%s%s",address_option,address_str,seed_str,length_str);
	        /*Converting string to integers*/
		address = str_to_int(address_str);
		ver_seed = str_to_int(seed_str);
		ver_length = str_to_int(length_str);
       }

	/*if the address input type is absolute hexadecimal address*/
	if(strcmp(address_option,"abs")==0)
	{
		abs_address = address;
		/*Checks if the address entered is a valid address*/
		/*Flag for setting if it is a valid address*/
		int flag = 0;
        	for((ptr=ptr_start); (ptr!=ptr_end);ptr++)
        	{
			/*Checks if the address is the start address of any memory block*/
                	if(ptr == (uint32_t *)abs_address)
                	{
                        	PRINT("\n\rValid Address\n\r");
                        	/*Flag is set if it is a valid address*/
                        	flag =1;
                	}
        	}

		/*Flag remains 0 if it is not a valid address*/
        	if(flag ==0)
		{
			if (ptr_start == NULL)
			{
			      //Condition to check if memory is allocated yet.
                   PRINT("\n\raddress not allocated, Please type allocate to proceed\n\r");
			       /*Goes to the end of the function if it ia not a valid address*/
			      ptr = NULL; 
			      goto end;
			}
			else
			{
			     //Condition to check if address entered by the user is invalid
                  PRINT("\n\rNot a valid address\n\r");
			       /*Goes to the end of the function*/
                  ptr = NULL;
			       goto end;
			}
		}
	}

	/*if the address input type is of block number*/
	else if(strcmp(address_option,"block")==0)
	{
		/*assigns actual address from block number*/
		int32_t block_no_count;
		for((ptr = ptr_start), (block_no_count = 1);(ptr!=ptr_end);ptr++,block_no_count++)
		{
			if(block_no_count == address)
			{
				PRINT("\n\rValid memory block\n\r");
#ifdef FRDM
				abs_address = (int32_t)ptr;
#else
				abs_address = (int64_t)ptr;
#endif
				/*Flag set to 1 if it is a valid address block*/
				flag = 1;
			}
		}

		/*Enters if it is not a valid block number*/
		if(flag ==0)
		{
			if (ptr_start == NULL)
			{
			       //Condition to check if the memory hasnt been allocated yet
                   PRINT("\n\raddress not allocated, Please type allocate to proceed\n\r");
			       /*Goes to the end of the function if it ia not a valid address*/
			       ptr = NULL; 
			       goto end;
			}
			else
			{
			        //Condition to check if the address entered by the user is invalid
                    PRINT("\n\rNot a valid address\n\r");
			        /*Goes to the end of the function*/
			        ptr = NULL;
				goto end;
			}
		}

	}
	else
	{
		/*enters if the user enters an invalid address type*/
		PRINT("\n\rNot a valid input address type\n\r");
		goto end;
	}		
	/*count increments if each number in pattern matches with that of the pattern stored in memory*/
	uint32_t count_match = 0;


#ifdef LINUX

	/*Gets the start time of verify operation*/
	clock_t begin = clock();

#else
				cnt_start_value = counter;

#endif

	/*Genreates pattern based on the the seed value and length, it verifies with the pattern stored in the memory*/
	ptr = (uint32_t *)abs_address;
	for(uint32_t count =1; count <= ver_length; ++count,++ptr)
        {
	      ver_seed = (7 * ver_seed) % 8191;
	      PRINT("\n\rExpected %dth value %d \n\r",count,ver_seed);
#ifdef LINUX
	      PRINT("\n\rActual value found %d at %p\n\r",(*ptr),ptr);
#else
	      PRINT("\n\rActual value found %d at %x\n\r",(*ptr),ptr);
#endif

	      /*counter increments if each number in pattern matches with the number in memory*/
	      if(ver_seed == (*ptr))
	      {
		      count_match++;
	      }

	      /*the pattern is verified and it as expected if each element matches with the pattern element in memory*/
	      if(count_match == ver_length)
		{
			PRINT("\n\rVerified and it is as expected\n\r");
		}
	}
	/*When the pattern do not match*/
	if(count_match!= ver_length)
	{
		PRINT("\n\rThey do not match\n\r");
	}

#ifdef LINUX

	/*Gets the end time after verify operation*/
	clock_t end = clock();

	/*Calculates the total time taken for verify operation*/
	double time_taken = (double) (end - begin)/CLOCKS_PER_SEC;
	PRINT("The time taken for the inversion operation is %lf seconds\n",time_taken);

#else
	cnt_end_value = counter;

	execution_cycle = cnt_end_value - cnt_start_value;


	PRINT("The time taken for the inversion operation is %d ms\n\r", execution_cycle);




#endif
end:
	PRINT("\n\r**********************************************\n\r");

	return 1;
}


