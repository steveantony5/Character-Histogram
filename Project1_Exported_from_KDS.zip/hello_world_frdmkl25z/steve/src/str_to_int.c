/*************************************************************************
 * Filename: str_to_int.c
 * Author: Steve and Swarupa
 *
 * 
 * Description : For converting string to integer
 * ***********************************************************************/

#include "str_to_int.h"

int str_to_int(char str[20])
{
	int32_t len = 0;
	len = strlen(str);
	int32_t result=0;
        for(int8_t i=0; i<len; i++)
	{
	       result = result * 10 + ( str[i] - '0' );
	}
	return result;
}
