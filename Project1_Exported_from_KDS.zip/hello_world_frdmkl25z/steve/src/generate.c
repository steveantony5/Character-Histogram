/*********************************************************
 * Author : Steve and Swarupa
 * Filename: generate.c
 * Date created : 09/30/2018
 *
 * Description: This .c file generates Pseudo random numbers for any length based on the seed value
 * *****************************************************/

/*Header Files*/
#include "generate.h"

int generate(char param[40])
{
#ifdef FRDM

	uint32_t cnt_start_value;
	uint32_t cnt_end_value;
	uint32_t execution_cycle;    //actual execution cycle
#endif
	/*For checking if the address entered is a valid address*/
	uint32_t *ptr=NULL;

#ifdef FRDM
	/*For getting the address from where the pattern has to be stored*/
	int32_t address = 0;

	/*for stroing the absolute address*/
	int32_t abs_address = 0;
#else
	/*For getting the address from where the pattern has to be stored*/
		int64_t address = 0;

		/*for stroing the absolute address*/
		int64_t abs_address = 0;
#endif
	
	/*For holding the seed value for the pattern*/
	uint32_t seed = 0;

	/*For storing the length of the pattern to be generated*/
	uint32_t length = 0;

	/*For setting if it is a valid address*/
	int8_t flag =0;
	
	/*Option for the type of address input*/
	char address_option[10];
	memset(address_option,0,sizeof(address_option));

	/*For storing the input trings*/
	char seed_str[10],length_str[10],address_str[20];
	memset(seed_str,0,sizeof(seed_str));
	memset(length_str,0,sizeof(length_str));
	memset(address_str,0,sizeof(address_str));


	/*Separating the input parameters*/
	/*When input address is of absolute type*/
	sscanf(param,"%s",address_option);
	/*Converting from string to integers*/
	if(strcmp(address_option,"abs")==0)
	{
		memset(address_option,0,sizeof(address_option));       
		sscanf(param,"%s%lx%s%s",address_option,&address,seed_str,length_str);
	       /*Converting from string to integers*/
	       seed = str_to_int(seed_str);
	       length = str_to_int(length_str);
	}

        /*Separating the input parameters when input address is of block type*/
        else
	{
		memset(address_option,0,sizeof(address_option));
		sscanf(param,"%s%s%s%s",address_option,address_str,seed_str,length_str);
		/*Converting from string to integers*/
		address = str_to_int(address_str);
   		seed = str_to_int(seed_str);
		length = str_to_int(length_str);
       }


	/*if the address is entered as absolute hexadecimal address*/
	if(strcmp(address_option,"abs")==0)
	{
		abs_address = address;

		/*Checks if the address is a valid addres*/
		/*Flag for setting if it is a valid address*/
		for((ptr=ptr_start); (ptr!=ptr_end);ptr++)
		{
			/*Checks if the address is the start address of any of the allocated memory block*/
			if(ptr== (uint32_t *)abs_address)
			{
				PRINT("\n\rValid Address\n\r");
				/*Flag set to 1 if it is a valid address*/
				flag =1;
			}
		}
	
		/*Flag remains 0 if it is not a valid address*/
		if(flag ==0)
		{
			if (ptr_start == NULL)
			{
 				   //Condition to check if memory has been allocated.
			       PRINT("\n\raddress not allocated, Please type allocate to proceed\n\r");
			       /*Goes to the end of the function if it ia not a valid address*/
			       ptr = NULL;
			       goto end;
			}
			else
			{ 
                   //Condition to check if the address entered by the user is invalid
			       PRINT("\n\rNot a valid address\n\r");
			       /*Goes to the end of the function*/
			       ptr = NULL;
			       goto end;
			}

		}
	}
	/*if the address is inputed as block number*/
	else if(strcmp(address_option,"block")==0)
	{
		ptr = NULL;
		/*converts the blocks number into address*/
		uint32_t block_no_count;
		for((ptr = ptr_start), (block_no_count = 1);(ptr!=ptr_end);ptr++,block_no_count++)
		{
			if(block_no_count == address)
			{
				PRINT("\n\rValid memory block\n\r");
#ifdef FRDM
				abs_address = (int32_t)ptr;
#else
				abs_address = (int64_t)ptr;
#endif
				flag = 1;
			}
		}
		
		/*Enters if block address is not valid*/
		if(flag ==0)
		{
			if (ptr_start == NULL)
	        	{
			       //Condition to check if the memory has been allocated yet
                    PRINT("\n\raddress not allocated, Please type allocate to proceed\n\r");
			        /*Goes to the end of the function if it ia not a valid address*/
			        ptr = NULL;
				goto end;
			}
			else
			{
                    //Condition to check if the address entered by the user is invalid
			        PRINT("\n\rNot a valid address\n\r");
			        /*Goes to the end of the function*/
			        ptr = NULL;
				goto end;
			}

		}

	}
	else
	{
		/*enters if the user enters an invalid address type*/
		PRINT("\n\rNot a valid input address type\n\r");
		ptr = NULL;
		goto end;
	}		
		
	/*Counts the number of memory blocks available from the address given by user*/
	ptr = (uint32_t *)abs_address;
	uint32_t count = 0;
	for((ptr=(uint32_t *)abs_address); (ptr!=ptr_end);(ptr++))
	{
		count++;
	}
	
	/*Checks if the length of the pattern to be generated is greater than the number of available memory blocks from the address given by user*/
	if(length>count)
	{	
		PRINT("\n\rThe allocated memory is not sufficient\n\r");
		ptr = NULL;
		goto end;
	}
	
#ifdef LINUX
	/*Gets the begin time of the generate operation*/
	clock_t begin = clock();
#else
	   cnt_start_value = counter;
#endif

	/*Generates pattern for the seed value and the length given*/
	ptr = (uint32_t *)abs_address;	
	for(uint32_t count =1; count <= length; count++,(ptr)++)
	{
		/*Formula used for psue random number generation*/
		seed = (7 * seed) % 8191;
		PRINT("%d ",seed);
		*ptr = seed;
	}
#ifdef LINUX
	/*Gets the end time of generate operation*/
	clock_t end = clock();

	/*Calculates the time taken for pattern generation*/
	double time_taken = (double) (end - begin)/CLOCKS_PER_SEC;



	PRINT("\nTime take to generate the pattern is %lf seconds\n",time_taken);
#else
	cnt_end_value = counter;

	execution_cycle = cnt_end_value - cnt_start_value;

	PRINT("The time taken for the inversion operation is %d ms\n\r", execution_cycle);



#endif

	PRINT("\n\r");
end:
	PRINT("\n\r***************************************************\n\r");
	if(ptr != NULL)
		return 1;		
	else
		return 0;
}
