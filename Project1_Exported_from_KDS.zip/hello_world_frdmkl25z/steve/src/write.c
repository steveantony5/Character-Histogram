/******************************************************
 * Author : Steve and Swarupa
 * Filename : write.c
 *Date Created: 09/29/2018
 * 
 * Description: This .c file helps to write unsigned hexadecimal data to any allocated memory location chosen by the user
 * ***************************************************/
/*Header section*/
#include "write.h"

int write_memory(char param[40])
{
	               
	/*For checking if the user entered address is a valid address*/
	uint32_t *ptr= NULL;

#ifdef FRDM
	/*for storing the actual block address*/
	int32_t abs_address = 0;

	/*for storing the address input parameter*/
	/*either block number or abs address*/ 
	int32_t address = 0;

#else
	/*for storing the actual block address*/
		int64_t abs_address = 0;

		/*for storing the address input parameter*/
		/*either block number or abs address*/
		int64_t address = 0;
#endif

	/*For setting if it is a valid address*/
	int8_t flag =0;
	
	/*Option for the type of address input*/
	char address_option[10];
	memset(address_option,0,sizeof(address_option));

	/*For string the data to be written*/
	uint32_t data = 0;

	/*for stroing the address string input parameter*/
	char address_str[15];
	memset(address_str,0,sizeof(address_str));

	/*separating the address input*/
	sscanf(param,"%s",address_option);
	/*Separating the inputs when address is given as absolute address*/
	if(strcmp(address_option,"abs")==0)
	{
#ifdef FRDM
		sscanf(param,"%s%lx%lx",address_option,&address,&data);
#else
		sscanf(param,"%s%lx%x",address_option,&address,&data);
#endif

	}
	/*Separating the inputs when address is given as block number*/
	else
	{
#ifdef FRDM
		sscanf(param,"%s%s%lx",address_option,address_str,&data);
#else
		sscanf(param,"%s%s%x",address_option,address_str,&data);
#endif
		/*Converting string to integer*/
		address = str_to_int(address_str);
	}


	/*Checks if it is a valid address when address is of absolute type*/
	if(strcmp(address_option,"abs")==0)
	{
		abs_address = address;

	        /*Checks if the user entered address is a valid address*/
		/*Flag is set if it is a valid address*/
        	for((ptr=ptr_start); (ptr!=ptr_end);ptr++)
		{
			/* Address is valid if it is the start of any allocated memory block*/
			if(ptr== (uint32_t *)abs_address)
			{
				PRINT("\n\rValid address\n\r");
				/*Sets flag to 1 if the address is valid*/
				flag =1;
			}
		}	
	
		/*Flag remains 0 if it is not a valid address*/
		if(flag == 0)
		{
               //condition to check if memory has been allocated yet
               if (ptr_start == NULL)
               {

			   PRINT("\n\raddress not allocated, Please type allocate to proceed\n\r");
			   /*Goes to the end of the function if it ia not a valid address*/
			   ptr = NULL;
			   goto end;

	               	}
                      //Condition to check if address given by user is invalid
                       else 
            		{
                           PRINT("\n\rNot a valid address\n\r");
			   /*Goes to the end of the function*/
			   ptr = NULL;
                           goto end;
                        }
		}
	}

	/*When user enters address in terms of block number*/
        else if(strcmp(address_option,"block")==0)
	{
		/*checks if the block number input is valid*/
		int32_t block_no_count;
                for((ptr = ptr_start), (block_no_count = 1);(ptr!=ptr_end);ptr++,block_no_count++)
                {
	               if(block_no_count == address)
	               {
		               PRINT("\n\rValid memory block\n\r");
					   
#ifdef FRDM
					   abs_address = (int32_t)ptr;
#else
					   abs_address = (int64_t)ptr;
#endif
			       /*sets if the block input is valid*/
		               flag = 1;
		       }
		}

		/*Enters if the block input is not valid*/
     		if(flag ==0)
                {
			if (ptr_start == NULL)
		        {

                               //condition to check if memory has been allocated yet
		               PRINT("\n\raddress not allocated, Please type allocate to proceed\n\r");
		               /*Goes to the end of the function if it ia not a valid address*/
		               ptr = NULL;
			       goto end;
	                }
	                else
	                {       
                               //Condition to check if address given by user is invalid
	                       PRINT("\n\rNot a valid address\n\r");
	                       /*Goes to the end of the function*/
			       ptr = NULL;
	                       goto end;
	                }
	        }
	}

	else
        {
                /*enters if the user enters an invalid address type*/
                PRINT("\n\rNot a valid address input type\n\r");
		ptr = NULL;
                goto end;
	}

	ptr = (uint32_t *)abs_address;
		
	/*Writing the data*/
	*ptr = data;
#ifdef LINUX
	PRINT("\n\rThe value %x has been stored in location %p \n\r",data, ptr);
#else
	PRINT("\n\rThe value %x has been stored in location %x \n\r",data, ptr);
#endif


end:   PRINT("\n\r************************************************\n\r");
	
       if(ptr!=NULL)
	       	return 1;        
       else
		return 0;

}	

