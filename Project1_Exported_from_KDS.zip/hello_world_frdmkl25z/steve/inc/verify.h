/************************************************************************************
 * File name: verify.h
 * Author: Steve and Swarupa
 * *********************************************************************************/

#ifndef VERIFY_H_
	#define VERIFY_H_

	/*Header File*/

	#include <stdio.h>
	#include <stdint.h>
	#include "main.h"

	#ifdef LINUX
		#include <time.h>
	#endif // end of LINUX

	#include <string.h>
	#include "str_to_int.h"

#endif
