/*********************************************************
 * Filename : free.h
 * Author: Steve and Swarupa
 *
 *******************************************************/


 #ifndef FREE_H_
 	#define FREE_H_


	/*Header section*/
	#include <stdio.h>
	#include <stdlib.h>
	#include <stdint.h>
	#include "main.h"

#endif //end of FREE_H_
