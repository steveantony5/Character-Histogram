/************************************************************************************
 * File name: help.h
 * Author: Steve and Swarupa
 * *********************************************************************************/

#ifndef HELP_H_
 	#define HELP_H_


	/*Header Files*/
	#include "stdio.h"
	#include "main.h"

	/*function prototype declaration*/
	int help(char[]);

#endif //end of HELP_H_
