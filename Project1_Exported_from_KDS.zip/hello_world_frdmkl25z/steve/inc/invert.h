/************************************************************************************
 * File name: invert.h
 * Author: Steve and Swarupa
 * *********************************************************************************/


 #ifndef INVERT_H_
 	#define INVERT_H_


	/*Header Files*/
	#include <stdio.h>
	#include <stdint.h>
	#include <string.h>
	#include "main.h"

	#ifdef LINUX
		#include <time.h>
	#endif //end of LINUX

	#include "str_to_int.h"

	/*Macro Definition*/
	#define FULL_RANGE_VALUE (4294967295)


#endif //end of INVERT_H_
