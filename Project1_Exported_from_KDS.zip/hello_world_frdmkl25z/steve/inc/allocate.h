/************************************************************************************
 * File name: allocate.h
 * Author: Steve and Swarupa
 * *********************************************************************************/

/*Header Files*/

 #ifndef ALLOCATE_H_
 	#define ALLOCATE_H_

	#include <stdio.h>
	#include <stdint.h>
	#include <stdlib.h>
	#include <string.h>
	#include "str_to_int.h"
	#include "main.h"

#endif //end of ALLOCATE_H_
