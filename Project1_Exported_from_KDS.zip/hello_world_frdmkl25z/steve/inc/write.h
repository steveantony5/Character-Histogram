/************************************************************************************
 * File name: write.h
 * Author: Steve and Swarupa
 * *********************************************************************************/

#ifndef WRITE_H_
 	#define WRITE_H_


	/*Header files*/
	#include <stdio.h>
	#include <stdlib.h>
	#include <stdint.h>
	#include <string.h>
	#include "str_to_int.h"
	#include "main.h"


#endif //End of WRITE_H_
