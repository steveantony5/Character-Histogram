/************************************************************************************
 * File name: generate.h
 * Author: Steve and Swarupa
 * *********************************************************************************/

 #ifndef GENERATE_H_
 	#define GENERATE_H_


	/*Header Files*/
	#include <stdio.h>
	#include <stdint.h>
	#include "main.h"

	#ifdef LINUX
		#include <time.h>
	#endif //end of LINUX

	#include <string.h>
	#include "str_to_int.h"


#endif //end of GENERATE_H_
