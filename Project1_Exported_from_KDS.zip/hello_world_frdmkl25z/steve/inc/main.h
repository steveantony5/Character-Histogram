/*********************************************
 * Filename: main.h
 * Author : Steve and Swarupa
 * ******************************************/

#ifndef MAIN_H_
	#define MAIN_H_

//#define LINUX
#define FRDM

	/*Header files*/

	#include<stdio.h>
	#include<string.h>
	#include<stdlib.h>
	#include<stdint.h>

	#ifdef FRDM
		#include "board.h"
		#include "fsl_lptmr_driver.h"
		#include "fsl_debug_console.h"
		#include "MKL25Z4.h"
		#define PRINT PRINTF
		#define SYSTICK_CTRL (*((volatile unsigned long *) (0xE000E010)))
		#define SYSTICK_LOAD (*((volatile unsigned long *) (0xE000E014)))
		#define SYSTICK_VAL (*((volatile unsigned long *) (0xE000E018)))


	#endif //end of FRDM

#ifdef LINUX
		#define PRINT printf

	#endif //end of LINUX

//GLOBAL FUNCTIONS
int allocate(char[]);
int display(char[]);
int free_memory(char[]);
int generate(char[]);
int help(char[]);
int invert(char[]);
int str_to_int(char[]);
int verify(char[]);
int write_memory(char[]);
void sys_init(void);
void SysTick_Handler(void);

extern uint32_t *ptr_start, *ptr_end;
extern volatile int32_t counter;

#endif //end of MAIN_H_
