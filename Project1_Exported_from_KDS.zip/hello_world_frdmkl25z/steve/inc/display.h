/************************************************************************************
 * File name: display.h
 * Author: Steve and Swarupa
 * *********************************************************************************/


 #ifndef DISPLAY_H_
 	#define DISPLAY_H_


	/*Header Files*/
	#include <stdio.h>
	#include <stdint.h>
	#include <string.h>
	#include "str_to_int.h"
	#include "main.h"


#endif //end of DISPLAY_H_
