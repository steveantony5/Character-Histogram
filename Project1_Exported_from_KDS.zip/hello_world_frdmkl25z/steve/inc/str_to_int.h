/***************************************************************************
 * File: str_to_int.h
 * Author : Steve and Swarupa
 *
 * Description: For converting string to integers values
 * ************************************************************************/
#ifndef STR_TO_INT_H
 	#define STR_TO_INT_H

	#include<stdint.h>
	#include<string.h>
	#include "main.h"

	/*Functon prototype*/

	int str_to_int(char[]);

#endif //end of STR_TO_INT_H
